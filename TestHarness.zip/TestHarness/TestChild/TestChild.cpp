#include "DllLoader.h"

using std::string;

int main() {
	string dllDirectory = "..\\Dll\\";
	string dllName = "Dll2.dll";
	string dllPath = dllDirectory + dllName;
	DllLoader dllLoader = DllLoader(dllPath);
	dllLoader.TestITest();
}