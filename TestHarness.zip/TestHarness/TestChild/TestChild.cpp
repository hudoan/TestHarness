#include "DllLoader.h"
#include <iostream>
using std::string;

int main() {
	string dllDirectory = "..\\Dll\\";
	string dllName = "Dll2.dll";
	string dllPath = dllDirectory + dllName;
	DllLoader dllLoader = DllLoader(dllPath);
	dllLoader.TestITest();
	TestResult testResult = dllLoader.getTestResult();
	std::cout << testResult.dll_path_<< std::endl;
	std::cout << testResult.test_result_ << std::endl;
	std::cout << testResult.log_message_ << std::endl;
	//std::cout << testResult.log_message_ << std::endl;


	

}