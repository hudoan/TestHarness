#ifdef DLL2_EXPORTS
#define DLL2_API __declspec(dllexport)
#else
#define DLL2_API __declspec(dllimport)
#endif

#include "ITest.h"

class TestClass2 : public ITest {

public:
	bool test() override;
};


extern "C" DLL2_API TestClass2 * createTest() {
	return new TestClass2;
};

