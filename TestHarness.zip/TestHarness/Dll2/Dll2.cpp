#include "pch.h"
#include "Dll2.h"

bool TestClass2::test()
{
	return true;
}
