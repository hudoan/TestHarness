#ifndef ITEST_H
#define ITEST_H

class  ITest
{
public:
	virtual ~ITest() {};
	virtual bool test() = 0;
};
#endif
