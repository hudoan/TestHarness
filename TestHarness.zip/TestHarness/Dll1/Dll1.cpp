#include "pch.h"
#include "Dll1.h"

bool TestClass1::test()
{
	return false;
}
